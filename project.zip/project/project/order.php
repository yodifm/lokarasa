<?php
    if(isset($_POST['submit'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $ginger = $_POST['ginger'];
        $address = $_POST['address'];
        header("location:https://api.whatsapp.com/send?phone=6282213172548&text=%0ANama:%20$name%0AEmail:%20$email%0APhone Number:%20$phone%0AType of Ginger:$ginger%0AAddress:$address");
      
        
    }
    else{
        echo"<script>
            window.location=history.go(-1);
        </script>";
    }

?>